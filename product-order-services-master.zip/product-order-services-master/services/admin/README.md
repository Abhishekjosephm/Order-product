## Overview
Shop information management, Members role management
