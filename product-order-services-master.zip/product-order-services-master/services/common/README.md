## Overview
This project contains prototype modules for making a simple product order system based on micro-service architecture. It based on [Spring](https://spring.io/) framework.

## License
This project is currently available under the [MIT](https://github.com/congcoi123/product-order-services/blob/master/LICENSE) License.

## Installation
You can get the sources:
```
git clone https://github.com/congcoi123/product-order-services.git
```

## Manual
### Project Structure
Coming soon !

### How to start
Coming soon !

### Configurations
Coming soon !

### How to deploy
Coming soon !

> Happy coding !
