## Overview

API Gateway is a concept of having a single point of entry to access all of the services in the backend. So, when any device wants to access resources from the server, they make a call to the API-Gateway. API-Gateway then reaches out to rest of the services which actually take care of serving the user with what they need.
